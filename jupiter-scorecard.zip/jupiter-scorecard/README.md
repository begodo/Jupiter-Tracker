# Jupiter Scorecard — Automated Device Time System

Automatically scrapes Jupiter Ed grades every Friday at 4:00 PM, scores them against the Device Time point system, and emails a formatted scorecard to you and your wife.

---

## How It Works

1. **Netlify scheduled function** triggers every Friday at 4 PM ET
2. **Playwright headless browser** logs into Jupiter with your parent credentials
3. **Scoring engine** applies the grade/missing-assignment point system
4. **HTML email** with full scorecard, priority actions, and Qustodio settings is sent to both parents

---

## Setup: Step by Step

### Step 1 — Prerequisites

- A [Netlify account](https://netlify.com) (free tier is sufficient)
- [Node.js](https://nodejs.org) 18+ installed locally
- [Git](https://git-scm.com) installed locally
- An SMTP email account for sending (see SMTP options below)

---

### Step 2 — Get the Code onto Netlify

**Option A: Deploy via GitHub (recommended)**

1. Create a new private GitHub repository
2. Push this project folder to it:
   ```bash
   git init
   git add .
   git commit -m "Initial Jupiter scorecard setup"
   git remote add origin https://github.com/YOUR_USERNAME/jupiter-scorecard.git
   git push -u origin main
   ```
3. In Netlify: **Add new site → Import from Git → Connect to GitHub → Select your repo**
4. Build settings: leave blank (no build command needed for functions-only projects)
5. Click **Deploy site**

**Option B: Deploy via Netlify CLI**
```bash
npm install -g netlify-cli
netlify login
netlify init
netlify deploy --prod
```

---

### Step 3 — Set Environment Variables

In Netlify: **Site → Site configuration → Environment variables → Add variable**

Add each of these:

| Variable | Value | Notes |
|---|---|---|
| `JUPITER_USERNAME` | Your Jupiter login email | Parent account preferred |
| `JUPITER_PASSWORD` | Your Jupiter password | Stored encrypted by Netlify |
| `JUPITER_SCHOOL_ID` | Your school's district code | Optional — check Jupiter login page |
| `JUPITER_STUDENT_ID` | Your son's name or student ID | Optional — only needed if you have multiple children on the account |
| `EMAIL_FROM` | `scorecard@yourdomain.com` | The "from" address |
| `EMAIL_TO` | `you@email.com,wife@email.com` | Comma-separated, no spaces |
| `SMTP_HOST` | See SMTP options below | |
| `SMTP_PORT` | `587` (or `465` for SSL) | |
| `SMTP_USER` | Your SMTP username | |
| `SMTP_PASS` | Your SMTP password or app password | |

---

### Step 4 — SMTP Email Options

You need an outgoing email service to send the scorecard. Three good options:

**Option A: Gmail App Password (easiest)**
1. Enable 2-factor authentication on your Gmail account
2. Go to [myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
3. Create an app password for "Mail"
4. Use these SMTP settings:
   - `SMTP_HOST`: `smtp.gmail.com`
   - `SMTP_PORT`: `587`
   - `SMTP_USER`: your Gmail address
   - `SMTP_PASS`: the 16-character app password (not your Gmail password)
   - `EMAIL_FROM`: your Gmail address

**Option B: Outlook / Microsoft 365**
- `SMTP_HOST`: `smtp.office365.com`
- `SMTP_PORT`: `587`
- `SMTP_USER`: your Microsoft email
- `SMTP_PASS`: your Microsoft password (or app password if MFA enabled)

**Option C: SendGrid (free up to 100 emails/day)**
1. Sign up at [sendgrid.com](https://sendgrid.com)
2. Create an API key under Settings → API Keys
3. Settings:
   - `SMTP_HOST`: `smtp.sendgrid.net`
   - `SMTP_PORT`: `587`
   - `SMTP_USER`: `apikey` (literally the word "apikey")
   - `SMTP_PASS`: your SendGrid API key

---

### Step 5 — Schedule the Function

1. In Netlify: **Site → Functions → scorecard**
2. Click **Schedule function**
3. Enter the cron expression: `0 20 * * 5`
   - This is 20:00 UTC = 4:00 PM EDT (Eastern Daylight Time, Apr–Nov)
   - In winter (EST, UTC-5): change to `0 21 * * 5` for 4:00 PM EST
   - Or just leave it at `0 20 * * 5` and accept a 1-hour shift in winter

Alternatively, add to `netlify.toml`:
```toml
[functions."scorecard"]
  schedule = "0 20 * * 5"
```

---

### Step 6 — Test Before Friday

**Test locally (no Jupiter, no email):**
```bash
npm install
node src/test-local.js
```
This writes `test-output.html` — open it in a browser to preview the email.

**Test the live function manually:**
1. Set `USE_MOCK_DATA=true` in your Netlify environment variables
2. In Netlify: **Functions → scorecard → Test function**
3. Check your email — you should receive the scorecard within a minute
4. Remove `USE_MOCK_DATA` (or set it to `false`) when confirmed working

**Test with real Jupiter credentials locally:**
```bash
JUPITER_USERNAME=you@email.com \
JUPITER_PASSWORD=yourpassword \
USE_MOCK_DATA=false \
node -e "
  const { scrapeJupiter } = require('./src/jupiter');
  scrapeJupiter({ username: process.env.JUPITER_USERNAME, password: process.env.JUPITER_PASSWORD })
    .then(c => console.log(JSON.stringify(c, null, 2)))
    .catch(e => console.error(e.message));
"
```

---

## If Jupiter Scraping Breaks

Jupiter Ed occasionally updates their UI, which can break the scraper. Signs of this:
- You receive the ⚠️ failure alert email instead of the scorecard
- The Netlify function logs show "returned no classes"

**Quick fix — manual fallback:**
1. Log into Jupiter, note his grades and missing assignments
2. Edit `src/jupiter.js` → `mockJupiterData()` function
3. Update the grades to current values
4. Set `USE_MOCK_DATA=true` in Netlify environment variables
5. The function will use your manually updated data until the scraper is fixed

**To fix the scraper:**
1. In Netlify function logs, look for the debug screenshot path
2. The scraper uses multiple CSS selector strategies — you may need to inspect Jupiter's current HTML and update the selectors in `src/jupiter.js`

---

## Adjusting the Point System

All scoring logic is in `src/scoring.js`. Key functions:

- `gradeToPoints(pct)` — grade → points mapping
- `missingToPoints(count)` — missing assignments → deduction
- `tierFromTotal(total)` — weekly total → tier, times, blocks

Edit these values and redeploy if you want to adjust thresholds or time allotments.

---

## File Structure

```
jupiter-scorecard/
├── netlify/
│   └── functions/
│       └── scorecard.js        ← Main scheduled function
├── src/
│   ├── jupiter.js              ← Jupiter scraper + mock data
│   ├── scoring.js              ← Point system logic
│   ├── email-template.js       ← HTML email builder
│   └── test-local.js           ← Local test runner
├── package.json
├── netlify.toml
└── README.md
```

---

## Privacy & Security

- Jupiter credentials are stored as **encrypted Netlify environment variables** — never in code or version control
- The GitHub repository should be **private**
- The Netlify function runs in an isolated serverless environment
- No grade data is stored anywhere — it is fetched, scored, emailed, and discarded each run
