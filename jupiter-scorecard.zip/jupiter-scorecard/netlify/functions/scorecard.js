// ─────────────────────────────────────────────────────────────────────────────
// NETLIFY SCHEDULED FUNCTION — scorecard.js
// Runs every Friday at 4:00 PM Eastern (21:00 UTC).
// Set this schedule in Netlify dashboard → Functions → scorecard → Schedule.
//
// Required environment variables (set in Netlify → Site → Environment Variables):
//   JUPITER_USERNAME   — Jupiter parent login email or username
//   JUPITER_PASSWORD   — Jupiter parent login password
//   JUPITER_SCHOOL_ID  — School code (optional; needed by some district logins)
//   JUPITER_STUDENT_ID — Student name or ID if account has multiple students (optional)
//   EMAIL_FROM         — Sending address (e.g. scorecard@yourdomain.com)
//   EMAIL_TO           — Comma-separated recipient list (e.g. you@gmail.com,wife@gmail.com)
//   SMTP_HOST          — SMTP server (e.g. smtp.gmail.com)
//   SMTP_PORT          — SMTP port (587 for TLS, 465 for SSL)
//   SMTP_USER          — SMTP login username
//   SMTP_PASS          — SMTP login password or app password
// ─────────────────────────────────────────────────────────────────────────────

const { scrapeJupiter, mockJupiterData } = require('../../src/jupiter');
const { scoreWeek }                      = require('../../src/scoring');
const { buildEmail }                     = require('../../src/email-template');
const nodemailer                         = require('nodemailer');

// Netlify scheduled function export
// The `schedule` string is a cron expression: minute hour day month weekday
// 0 21 * * 5 = every Friday at 21:00 UTC = 4:00 PM Eastern (EST)
// During EDT (summer), Eastern is UTC-4, so 20:00 UTC = 4:00 PM EDT
// Netlify runs in UTC — adjust if needed for daylight saving time.
exports.handler = async function(event, context) {

  console.log('[Scorecard] Starting run at', new Date().toISOString());

  // ── 1. Validate environment ───────────────────────────────────────────────
  const required = ['JUPITER_USERNAME', 'JUPITER_PASSWORD', 'EMAIL_FROM', 'EMAIL_TO', 'SMTP_HOST', 'SMTP_PORT', 'SMTP_USER', 'SMTP_PASS'];
  const missing  = required.filter(k => !process.env[k]);
  if (missing.length > 0) {
    console.error('[Scorecard] Missing environment variables:', missing.join(', '));
    return { statusCode: 500, body: `Missing env vars: ${missing.join(', ')}` };
  }

  // ── 2. Scrape Jupiter ─────────────────────────────────────────────────────
  let rawClasses;
  const useMock = process.env.USE_MOCK_DATA === 'true'; // set this during local testing

  if (useMock) {
    console.log('[Scorecard] Using mock Jupiter data (USE_MOCK_DATA=true)');
    rawClasses = mockJupiterData();
  } else {
    try {
      rawClasses = await scrapeJupiter({
        username:  process.env.JUPITER_USERNAME,
        password:  process.env.JUPITER_PASSWORD,
        schoolId:  process.env.JUPITER_SCHOOL_ID  || '',
        studentId: process.env.JUPITER_STUDENT_ID || '',
      });
    } catch (scrapeErr) {
      console.error('[Scorecard] Jupiter scrape failed:', scrapeErr.message);
      // Send a failure alert email rather than silently failing
      await sendFailureEmail(scrapeErr.message);
      return { statusCode: 500, body: `Scrape failed: ${scrapeErr.message}` };
    }
  }

  console.log(`[Scorecard] Got ${rawClasses.length} classes from Jupiter.`);

  // ── 3. Score the week ─────────────────────────────────────────────────────
  const result  = scoreWeek(rawClasses);
  const runDate = new Date();

  console.log(`[Scorecard] Weekly total: ${result.weeklyTotal} → ${result.tier.label}`);

  // ── 4. Build email ────────────────────────────────────────────────────────
  const html = buildEmail(result, runDate);

  // ── 5. Send email ─────────────────────────────────────────────────────────
  const transporter = nodemailer.createTransport({
    host:   process.env.SMTP_HOST,
    port:   parseInt(process.env.SMTP_PORT, 10),
    secure: process.env.SMTP_PORT === '465',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  const recipients = process.env.EMAIL_TO.split(',').map(e => e.trim());
  const subject    = `📊 Device Time Scorecard — ${result.tier.emoji} ${result.tier.label} (${result.weeklyTotal > 0 ? '+' : ''}${result.weeklyTotal} pts) · ${runDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'America/New_York' })}`;

  try {
    const info = await transporter.sendMail({
      from:    process.env.EMAIL_FROM,
      to:      recipients.join(', '),
      subject,
      html,
    });
    console.log('[Scorecard] Email sent:', info.messageId);
  } catch (emailErr) {
    console.error('[Scorecard] Email send failed:', emailErr.message);
    return { statusCode: 500, body: `Email failed: ${emailErr.message}` };
  }

  return {
    statusCode: 200,
    body: JSON.stringify({
      success:     true,
      weeklyTotal: result.weeklyTotal,
      tier:        result.tier.label,
      classes:     result.scoredClasses.length,
      sentTo:      recipients,
    }),
  };
};

// ── Failure alert email ───────────────────────────────────────────────────────
async function sendFailureEmail(errorMessage) {
  try {
    const transporter = nodemailer.createTransport({
      host:   process.env.SMTP_HOST,
      port:   parseInt(process.env.SMTP_PORT, 10),
      secure: process.env.SMTP_PORT === '465',
      auth:   { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    });
    await transporter.sendMail({
      from:    process.env.EMAIL_FROM,
      to:      process.env.EMAIL_TO,
      subject: '⚠️ Device Time Scorecard — Jupiter scrape failed',
      html: `
        <p>The automated Jupiter scraper failed to run this week.</p>
        <p><strong>Error:</strong> ${errorMessage}</p>
        <p>You will need to check Jupiter manually and update Qustodio before the weekend.</p>
        <p>Log in at <a href="https://login.jupitered.com">login.jupitered.com</a></p>
      `,
    });
  } catch (e) {
    console.error('[Scorecard] Could not send failure alert:', e.message);
  }
}
