// ─────────────────────────────────────────────────────────────────────────────
// SCORECARD EMAIL TEMPLATE
// Generates a rich HTML email matching the visual style of the Word document.
// ─────────────────────────────────────────────────────────────────────────────

function formatDate(date) {
  return date.toLocaleDateString('en-US', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
    timeZone: 'America/New_York',
  });
}

function ptLabel(pts) {
  if (pts > 0) return `+${pts}`;
  return `${pts}`;
}

function ptColor(pts) {
  if (pts > 0)  return '#1E6B3C';
  if (pts < 0)  return '#7B1818';
  return '#404040';
}

function gradeColor(grade) {
  if (grade >= 93) return '#1E6B3C';
  if (grade >= 85) return '#2E75B6';
  if (grade >= 80) return '#404040';
  if (grade >= 70) return '#C55A11';
  return '#7B1818';
}

function rowBg(i) {
  return i % 2 === 0 ? '#ffffff' : '#f5f7fa';
}

/**
 * Build the full HTML email.
 * @param {Object} result - output from scoreWeek()
 * @param {Date}   runDate
 */
function buildEmail(result, runDate) {
  const { scoredClasses, totalGradePts, totalMissingPts, weeklyTotal, tier, actions } = result;
  const dateStr = formatDate(runDate);
  const nextCheckIn = new Date(runDate);
  nextCheckIn.setDate(nextCheckIn.getDate() + 7);

  // ── Class rows ─────────────────────────────────────────────────────────────
  const classRows = scoredClasses.map((c, i) => `
    <tr style="background:${rowBg(i)}">
      <td style="padding:10px 12px;font-weight:${c.missingCount > 0 ? '600' : 'normal'};color:#1F4E79">${c.name}</td>
      <td style="padding:10px 12px;text-align:center;font-weight:600;color:${gradeColor(c.grade)}">${c.grade.toFixed(1)}%</td>
      <td style="padding:10px 12px;text-align:center;font-weight:700;color:${ptColor(c.gradePts)}">${ptLabel(c.gradePts)}</td>
      <td style="padding:10px 12px;color:${c.missingCount > 0 ? '#7B1818' : '#767676'};font-size:13px">
        ${c.missingItems.length > 0 ? c.missingItems.join('<br>') : '—'}
      </td>
      <td style="padding:10px 12px;text-align:center;font-weight:700;color:${ptColor(c.missingPts)}">${c.missingPts < 0 ? c.missingPts : '0'}</td>
      <td style="padding:10px 12px;text-align:center;font-weight:800;font-size:15px;color:${ptColor(c.classPts)}">${ptLabel(c.classPts)}</td>
      <td style="padding:10px 12px;text-align:center;font-size:16px">${c.band.emoji}</td>
    </tr>
  `).join('');

  // ── Action items ───────────────────────────────────────────────────────────
  const actionRows = actions.map((a, i) => `
    <tr style="background:${rowBg(i)}">
      <td style="padding:8px 12px;text-align:center;font-weight:700;color:#1F4E79">${i + 1}</td>
      <td style="padding:8px 12px;font-weight:600;color:#1F4E79">${a.class}</td>
      <td style="padding:8px 12px;color:#404040;font-size:13px">${a.actions.join('<br>')}</td>
      <td style="padding:8px 12px;text-align:center;font-weight:700;color:${ptColor(-a.classPts)}">
        ${a.classPts < 0 ? `+${Math.abs(a.classPts)} possible` : '✓'}
      </td>
    </tr>
  `).join('');

  const noActions = actions.length === 0
    ? `<p style="color:#1E6B3C;font-weight:600;padding:12px">✅ No missing assignments and all grades on track. Great week.</p>`
    : '';

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Device Time Scorecard — ${dateStr}</title>
</head>
<body style="margin:0;padding:0;background:#f0f4f8;font-family:Arial,Helvetica,sans-serif;color:#404040">

<table width="100%" cellpadding="0" cellspacing="0" style="background:#f0f4f8;padding:24px 0">
<tr><td align="center">
<table width="680" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.12)">

  <!-- HEADER -->
  <tr>
    <td style="background:#1F4E79;padding:28px 32px">
      <p style="margin:0;color:#93c5fd;font-size:13px;letter-spacing:1px;text-transform:uppercase">Device Time System</p>
      <h1 style="margin:6px 0 4px;color:#ffffff;font-size:26px;font-weight:700">Weekly Scorecard</h1>
      <p style="margin:0;color:#bfdbfe;font-size:14px">${dateStr}</p>
    </td>
  </tr>

  <!-- RESULT BANNER -->
  <tr>
    <td style="background:${tier.bgColor};padding:20px 32px;border-bottom:3px solid ${tier.color}">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td>
            <p style="margin:0 0 4px;font-size:13px;color:#404040;text-transform:uppercase;letter-spacing:0.5px">Weekly Total</p>
            <p style="margin:0;font-size:42px;font-weight:800;color:${tier.color};line-height:1">${ptLabel(weeklyTotal)}</p>
          </td>
          <td style="padding-left:32px;border-left:2px solid ${tier.color}">
            <p style="margin:0 0 4px;font-size:20px;font-weight:700;color:${tier.color}">${tier.emoji} ${tier.label}</p>
            <p style="margin:0;font-size:13px;color:#404040"><strong>School nights:</strong> ${tier.schoolNightTime} · cutoff ${tier.schoolCutoff}</p>
            <p style="margin:4px 0 0;font-size:13px;color:#404040"><strong>Weekends / holidays:</strong> ${tier.weekendTime}</p>
            <p style="margin:4px 0 0;font-size:13px;color:#767676">${tier.weekendBlocks}</p>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- SCORECARD TABLE -->
  <tr>
    <td style="padding:28px 32px 0">
      <h2 style="margin:0 0 14px;font-size:16px;color:#1F4E79;border-bottom:2px solid #2E75B6;padding-bottom:6px">Grade Scorecard — All Classes</h2>
      <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:13px">
        <thead>
          <tr style="background:#1F4E79">
            <th style="padding:10px 12px;text-align:left;color:#fff;font-weight:600">Class</th>
            <th style="padding:10px 12px;text-align:center;color:#fff;font-weight:600">Grade</th>
            <th style="padding:10px 12px;text-align:center;color:#fff;font-weight:600">Grade Pts</th>
            <th style="padding:10px 12px;text-align:left;color:#fff;font-weight:600">Missing Assignments</th>
            <th style="padding:10px 12px;text-align:center;color:#fff;font-weight:600">Missing Pts</th>
            <th style="padding:10px 12px;text-align:center;color:#fff;font-weight:600">Class Total</th>
            <th style="padding:10px 12px;text-align:center;color:#fff;font-weight:600"></th>
          </tr>
        </thead>
        <tbody>
          ${classRows}
          <!-- TOTALS ROW -->
          <tr style="background:#1F4E79">
            <td style="padding:10px 12px;color:#fff;font-weight:700">WEEKLY TOTAL</td>
            <td style="padding:10px 12px"></td>
            <td style="padding:10px 12px;text-align:center;color:#fff;font-weight:700">${ptLabel(totalGradePts)}</td>
            <td style="padding:10px 12px"></td>
            <td style="padding:10px 12px;text-align:center;color:#fff;font-weight:700">${totalMissingPts}</td>
            <td style="padding:10px 12px;text-align:center;color:#fff;font-weight:800;font-size:16px">${ptLabel(weeklyTotal)}</td>
            <td style="padding:10px 12px;text-align:center">${tier.emoji}</td>
          </tr>
        </tbody>
      </table>
    </td>
  </tr>

  <!-- PRIORITY ACTIONS -->
  <tr>
    <td style="padding:24px 32px 0">
      <h2 style="margin:0 0 14px;font-size:16px;color:#1F4E79;border-bottom:2px solid #2E75B6;padding-bottom:6px">Priority Actions This Week</h2>
      ${noActions}
      ${actions.length > 0 ? `
      <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:13px">
        <thead>
          <tr style="background:#1F4E79">
            <th style="padding:8px 12px;color:#fff;width:30px">#</th>
            <th style="padding:8px 12px;text-align:left;color:#fff">Class</th>
            <th style="padding:8px 12px;text-align:left;color:#fff">Action</th>
            <th style="padding:8px 12px;text-align:center;color:#fff">Points at Stake</th>
          </tr>
        </thead>
        <tbody>${actionRows}</tbody>
      </table>` : ''}
    </td>
  </tr>

  <!-- QUSTODIO REMINDER -->
  <tr>
    <td style="padding:24px 32px 0">
      <table width="100%" cellpadding="0" cellspacing="0" style="background:#EBF3FB;border-radius:6px;border-left:4px solid #2E75B6">
        <tr>
          <td style="padding:16px 20px">
            <p style="margin:0 0 8px;font-weight:700;color:#1F4E79;font-size:14px">📱 Qustodio Settings for This Week</p>
            <p style="margin:0 0 4px;font-size:13px;color:#404040">
              <strong>School nights (Mon–Thu):</strong> ${tier.schoolNightTime} free time · Hard cutoff at <strong>${tier.schoolCutoff}</strong>
            </p>
            <p style="margin:0 0 4px;font-size:13px;color:#404040">
              <strong>Weekends &amp; holidays:</strong> ${tier.weekendTime} · Blocks: ${tier.weekendBlocks}
            </p>
            <p style="margin:8px 0 0;font-size:12px;color:#767676">
              Update Qustodio at <a href="https://family.qustodio.com" style="color:#2E75B6">family.qustodio.com</a> before Friday evening.
              Overnight Apple Screen Time block (9 PM–7 AM) remains unchanged at all tiers.
            </p>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- FOOTER -->
  <tr>
    <td style="padding:24px 32px 28px">
      <p style="margin:0;font-size:12px;color:#767676;border-top:1px solid #e5e7eb;padding-top:16px">
        Device Time System · Auto-generated from Jupiter Ed · ${dateStr}<br>
        Next scorecard: ${formatDate(nextCheckIn)} · 
        Phone calls and texts are never restricted at any tier.
      </p>
    </td>
  </tr>

</table>
</td></tr>
</table>

</body>
</html>`;
}

module.exports = { buildEmail };
