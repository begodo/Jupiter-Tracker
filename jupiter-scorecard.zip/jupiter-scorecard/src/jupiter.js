// ─────────────────────────────────────────────────────────────────────────────
// JUPITER ED SCRAPER
// Logs in with parent credentials and extracts grades + missing assignments.
// Uses Playwright with @sparticuz/chromium for Netlify serverless compatibility.
// ─────────────────────────────────────────────────────────────────────────────

const playwright  = require('playwright-core');
const chromium    = require('@sparticuz/chromium');

const JUPITER_URL = 'https://login.jupitered.com/login/';

/**
 * Scrape grades and missing assignments from Jupiter Ed.
 *
 * @param {Object} credentials
 *   { username, password, schoolId, studentId }
 *   schoolId and studentId are optional — needed only if the parent account
 *   manages multiple students or schools. Leave blank for single-student accounts.
 *
 * @returns {Array} classes — [{ name, grade, missingCount, missingItems[] }]
 */
async function scrapeJupiter(credentials) {
  let browser;
  try {
    // ── Launch browser ──────────────────────────────────────────────────────
    browser = await playwright.chromium.launch({
      args:            chromium.args,
      executablePath:  await chromium.executablePath(),
      headless:        true,
    });

    const context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      viewport:  { width: 1280, height: 800 },
    });
    const page = await context.newPage();

    // ── Log in ──────────────────────────────────────────────────────────────
    console.log('[Jupiter] Navigating to login page...');
    await page.goto(JUPITER_URL, { waitUntil: 'networkidle', timeout: 30000 });

    // Jupiter login form fields
    await page.fill('input[name="login_id"]',   credentials.username);
    await page.fill('input[name="login_pw"]',   credentials.password);

    // School field — Jupiter requires selecting your school
    // Some accounts have it pre-selected; others need a district/school code
    if (credentials.schoolId) {
      const schoolInput = page.locator('input[name="school"]');
      if (await schoolInput.count() > 0) {
        await schoolInput.fill(credentials.schoolId);
      }
    }

    await page.click('input[type="submit"], button[type="submit"]');
    await page.waitForNavigation({ waitUntil: 'networkidle', timeout: 20000 });

    // Check for login errors
    const errorEl = page.locator('.error, .alert-danger, [class*="error"]');
    if (await errorEl.count() > 0) {
      const errorText = await errorEl.first().innerText();
      throw new Error(`Jupiter login failed: ${errorText}`);
    }

    console.log('[Jupiter] Logged in successfully.');

    // ── Handle multi-student accounts ───────────────────────────────────────
    // If the parent account has multiple students, select the right one
    if (credentials.studentId) {
      const studentLink = page.locator(`a[data-student="${credentials.studentId}"], a:has-text("${credentials.studentId}")`);
      if (await studentLink.count() > 0) {
        await studentLink.first().click();
        await page.waitForNavigation({ waitUntil: 'networkidle', timeout: 15000 });
      }
    }

    // ── Navigate to grades page ─────────────────────────────────────────────
    // Try direct URL first, then fall back to nav link
    const currentUrl = page.url();
    if (!currentUrl.includes('grade')) {
      const gradeLink = page.locator('a[href*="grade"], a:has-text("Grades"), nav a:has-text("Grade")');
      if (await gradeLink.count() > 0) {
        await gradeLink.first().click();
        await page.waitForLoadState('networkidle', { timeout: 15000 });
      }
    }

    console.log('[Jupiter] On grades page:', page.url());

    // ── Extract class data ──────────────────────────────────────────────────
    // Jupiter renders grades in a table/list. The structure varies slightly
    // by school configuration, so we try multiple selectors.
    const classes = await page.evaluate(() => {
      const results = [];

      // Strategy 1: Look for course rows with grade percentages
      // Jupiter typically uses a structure like:
      // .course-row or tr with class name + grade
      const courseSelectors = [
        '.course',
        '.class-row',
        'tr[data-course]',
        '.gradebook-row',
        '[class*="course"]',
      ];

      let courseEls = [];
      for (const sel of courseSelectors) {
        courseEls = [...document.querySelectorAll(sel)];
        if (courseEls.length > 0) break;
      }

      // Strategy 2: Parse the full grade table if course selectors don't work
      if (courseEls.length === 0) {
        // Fallback: look for any element containing a percentage next to a class name
        const rows = [...document.querySelectorAll('tr, .row, [class*="row"]')];
        courseEls = rows.filter(row => {
          const text = row.textContent || '';
          return /\d{1,3}\.\d%|\d{1,3}%/.test(text) && text.length < 500;
        });
      }

      for (const el of courseEls) {
        const text = el.textContent || '';

        // Extract class name
        const nameEl = el.querySelector('.course-name, .class-name, [class*="name"], td:first-child, h3, h4');
        const name = nameEl
          ? nameEl.textContent.trim()
          : text.split('\n')[0].trim().substring(0, 60);

        if (!name || name.length < 2) continue;

        // Extract grade percentage
        const gradeMatch = text.match(/(\d{1,3}(?:\.\d{1,2})?)\s*%/);
        if (!gradeMatch) continue;
        const grade = parseFloat(gradeMatch[1]);
        if (isNaN(grade) || grade > 110) continue;

        // Extract missing assignments
        const missingItems = [];
        const missingEls = el.querySelectorAll(
          '[class*="missing"], [class*="late"], .missing, .late, [style*="red"], .assignment-missing'
        );
        for (const m of missingEls) {
          const mText = m.textContent.trim();
          if (mText && !missingItems.includes(mText)) {
            missingItems.push(mText);
          }
        }

        // Also scan for text patterns like "missing" near assignment names
        const allText = el.innerHTML;
        const missingPattern = /([^<]{5,80}?)\s*(?:<[^>]+>)*\s*missing/gi;
        let match;
        while ((match = missingPattern.exec(allText)) !== null) {
          const item = match[1].replace(/<[^>]+>/g, '').trim();
          if (item && item.length > 3 && !missingItems.includes(item)) {
            missingItems.push(item);
          }
        }

        results.push({ name, grade, missingCount: missingItems.length, missingItems });
      }

      return results;
    });

    // ── Fallback: screenshot-based extraction prompt ────────────────────────
    // If the DOM scrape returned nothing useful, take a screenshot for debugging
    if (classes.length === 0) {
      console.warn('[Jupiter] DOM scrape returned no classes. Taking debug screenshot...');
      await page.screenshot({ path: '/tmp/jupiter-debug.png', fullPage: true });
      throw new Error(
        'Jupiter scrape returned no classes. The page structure may have changed. ' +
        'Check the MANUAL_FALLBACK instructions in the README.'
      );
    }

    console.log(`[Jupiter] Extracted ${classes.length} classes.`);
    await browser.close();
    return classes;

  } catch (err) {
    if (browser) await browser.close().catch(() => {});
    throw err;
  }
}

/**
 * Local development fallback — use this to test the scoring and email
 * without actually hitting Jupiter. Returns the same structure scrapeJupiter()
 * would return. Replace with your son's actual current grades for testing.
 */
function mockJupiterData() {
  return [
    { name: "Physics Lab Term 2",                   grade: 85.7, missingCount: 1, missingItems: ["Lab#26: Thermal Energy Revisited"] },
    { name: "Geometry Term 2",                      grade: 63.6, missingCount: 1, missingItems: ["Unit 7 Test Corrections"] },
    { name: "Spanish II Term 2",                    grade: 92.9, missingCount: 0, missingItems: [] },
    { name: "Physical Education 9th Grade",         grade: 77.0, missingCount: 1, missingItems: ["Assignment due 2/6"] },
    { name: "Pre-AP World History Term 2",          grade: 77.6, missingCount: 1, missingItems: ["China Practice LEQ HW"] },
    { name: "Physics Term 2",                       grade: 88.2, missingCount: 0, missingItems: [] },
    { name: "English 9 Term 2",                     grade: 74.8, missingCount: 1, missingItems: ["Log #3 (ch 5-8) & Discussion"] },
    { name: "Rit Design & Drawing for Production",  grade: 87.5, missingCount: 1, missingItems: ["Exercise #6C2 - Additional Features"] },
  ];
}

module.exports = { scrapeJupiter, mockJupiterData };
