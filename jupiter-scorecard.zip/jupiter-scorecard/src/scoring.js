// ─────────────────────────────────────────────────────────────────────────────
// DEVICE TIME SCORING SYSTEM
// Matches the framework document exactly.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Convert a numeric grade percentage to grade points.
 * +2 = 93%+  |  +1 = 85–92%  |  0 = 80–84%  |  -1 = 70–79%  |  -2 = below 70%
 */
function gradeToPoints(pct) {
  if (pct >= 93) return  2;
  if (pct >= 85) return  1;
  if (pct >= 80) return  0;
  if (pct >= 70) return -1;
  return -2;
}

function gradeBand(pct) {
  if (pct >= 93) return { label: "Excellent",       emoji: "🟢", color: "#1E6B3C" };
  if (pct >= 85) return { label: "Good",             emoji: "🟢", color: "#1E6B3C" };
  if (pct >= 80) return { label: "Baseline",         emoji: "🟡", color: "#7F5B00" };
  if (pct >= 70) return { label: "Below Target",     emoji: "🟠", color: "#C55A11" };
  return           { label: "Needs Attention",  emoji: "🔴", color: "#7B1818" };
}

/**
 * Convert number of missing assignments to a point deduction.
 * 1 missing = -1  |  2 missing = -2  |  3+ missing = -3 (cap)
 */
function missingToPoints(count) {
  if (count <= 0) return 0;
  return -Math.min(count, 3);
}

/**
 * Score a single class.
 * @param {Object} cls - { name, grade (0–100), missingCount, missingItems[] }
 * @returns enriched class object with points
 */
function scoreClass(cls) {
  const gradePts   = gradeToPoints(cls.grade);
  const missingPts = missingToPoints(cls.missingCount);
  const classPts   = gradePts + missingPts;
  const band       = gradeBand(cls.grade);
  return {
    ...cls,
    gradePts,
    missingPts,
    classPts,
    band,
  };
}

/**
 * Determine the weekly tier from total points.
 */
function tierFromTotal(total) {
  if (total >= 10) return {
    label:          "Excellent",
    emoji:          "🟢",
    color:          "#1E6B3C",
    bgColor:        "#E2F0E8",
    schoolNightTime:"2.5 hours",
    schoolCutoff:   "8:30 PM",
    weekendTime:    "5 hours/day",
    weekendBlocks:  "10:00 AM–12:00 PM  +  2:00–5:00 PM  +  7:00–9:00 PM",
  };
  if (total >= 5) return {
    label:          "Good",
    emoji:          "🟢",
    color:          "#1E6B3C",
    bgColor:        "#E2F0E8",
    schoolNightTime:"2 hours",
    schoolCutoff:   "8:00 PM",
    weekendTime:    "4 hours/day",
    weekendBlocks:  "10:00 AM–12:00 PM  +  2:00–4:00 PM  +  7:00–9:00 PM",
  };
  if (total >= -4) return {
    label:          "On Track",
    emoji:          "🟡",
    color:          "#7F5B00",
    bgColor:        "#FFF3CD",
    schoolNightTime:"1.5 hours",
    schoolCutoff:   "7:30 PM",
    weekendTime:    "3 hours/day",
    weekendBlocks:  "10:00 AM–11:00 AM  +  2:00–3:00 PM  +  7:00–9:00 PM",
  };
  if (total >= -9) return {
    label:          "Below Target",
    emoji:          "🟠",
    color:          "#C55A11",
    bgColor:        "#FCE4D6",
    schoolNightTime:"1 hour",
    schoolCutoff:   "7:00 PM",
    weekendTime:    "2 hours/day",
    weekendBlocks:  "11:00 AM–12:00 PM  +  7:00–8:00 PM",
  };
  return {
    label:          "Needs Action",
    emoji:          "🔴",
    color:          "#7B1818",
    bgColor:        "#FCE4D6",
    schoolNightTime:"30 minutes",
    schoolCutoff:   "6:30 PM",
    weekendTime:    "1 hour/day",
    weekendBlocks:  "7:00–8:00 PM only",
  };
}

/**
 * Score a full week's worth of classes.
 * @param {Array} classes - array of { name, grade, missingCount, missingItems[] }
 * @returns { scoredClasses, totalGradePts, totalMissingPts, weeklyTotal, tier }
 */
function scoreWeek(classes) {
  const scoredClasses   = classes.map(scoreClass);
  const totalGradePts   = scoredClasses.reduce((s, c) => s + c.gradePts,   0);
  const totalMissingPts = scoredClasses.reduce((s, c) => s + c.missingPts, 0);
  const weeklyTotal     = scoredClasses.reduce((s, c) => s + c.classPts,   0);
  const tier            = tierFromTotal(weeklyTotal);

  // Identify priority actions — classes with missing assignments, sorted by impact
  const actions = scoredClasses
    .filter(c => c.missingCount > 0 || c.grade < 80)
    .sort((a, b) => a.classPts - b.classPts)  // worst first
    .map(c => {
      const items = [];
      if (c.missingItems && c.missingItems.length > 0) {
        items.push(...c.missingItems.map(i => `Submit: ${i}`));
      }
      if (c.grade < 70) items.push(`Bring grade above 70% (currently ${c.grade.toFixed(1)}%)`);
      else if (c.grade < 80) items.push(`Bring grade above 80% (currently ${c.grade.toFixed(1)}%)`);
      return { class: c.name, classPts: c.classPts, actions: items };
    });

  return { scoredClasses, totalGradePts, totalMissingPts, weeklyTotal, tier, actions };
}

module.exports = { scoreWeek, gradeToPoints, missingToPoints, tierFromTotal, gradeBand };
