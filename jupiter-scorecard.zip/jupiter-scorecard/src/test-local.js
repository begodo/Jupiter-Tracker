// ─────────────────────────────────────────────────────────────────────────────
// LOCAL TEST RUNNER
// Run with: node src/test-local.js
// Generates the scorecard email as a local HTML file you can open in a browser.
// Does NOT hit Jupiter or send email — safe to run any time.
// ─────────────────────────────────────────────────────────────────────────────

const { mockJupiterData } = require('./jupiter');
const { scoreWeek }       = require('./scoring');
const { buildEmail }      = require('./email-template');
const fs                  = require('fs');
const path                = require('path');

console.log('Running local test with mock Jupiter data...\n');

const rawClasses = mockJupiterData();
const result     = scoreWeek(rawClasses);
const runDate    = new Date();
const html       = buildEmail(result, runDate);

// Write to a local HTML file
const outPath = path.join(__dirname, '../test-output.html');
fs.writeFileSync(outPath, html);

// Print summary to console
console.log('='.repeat(60));
console.log('WEEKLY SCORECARD SUMMARY');
console.log('='.repeat(60));
console.log(`Run date:     ${runDate.toDateString()}`);
console.log(`Weekly total: ${result.weeklyTotal > 0 ? '+' : ''}${result.weeklyTotal}`);
console.log(`Tier:         ${result.tier.emoji} ${result.tier.label}`);
console.log(`School night: ${result.tier.schoolNightTime} (cutoff ${result.tier.schoolCutoff})`);
console.log(`Weekend:      ${result.tier.weekendTime}`);
console.log(`Blocks:       ${result.tier.weekendBlocks}`);
console.log('-'.repeat(60));
console.log('CLASS BREAKDOWN:');
result.scoredClasses.forEach(c => {
  const pts   = c.classPts > 0 ? `+${c.classPts}` : `${c.classPts}`;
  const miss  = c.missingCount > 0 ? ` [${c.missingCount} missing]` : '';
  console.log(`  ${c.band.emoji}  ${c.name.padEnd(45)} ${c.grade.toFixed(1)}%  →  ${pts}${miss}`);
});
console.log('-'.repeat(60));
console.log(`Grade pts:    ${result.totalGradePts > 0 ? '+' : ''}${result.totalGradePts}`);
console.log(`Missing pts:  ${result.totalMissingPts}`);
console.log(`TOTAL:        ${result.weeklyTotal > 0 ? '+' : ''}${result.weeklyTotal}`);
console.log('='.repeat(60));

if (result.actions.length > 0) {
  console.log('\nPRIORITY ACTIONS:');
  result.actions.forEach((a, i) => {
    console.log(`  ${i + 1}. ${a.class}`);
    a.actions.forEach(act => console.log(`     → ${act}`));
  });
}

console.log(`\n✅ HTML preview written to: ${outPath}`);
console.log('   Open this file in a browser to preview the email.\n');
